# S05 live trial

- Variant: C (LLM-assisted diagnostic and deterministic remediation)
- Observed outcome: escalated
- Scenario verdict: pass
- Fault start UTC: 2026-10-12T09:24:00Z
- Intended image: registry-01.example.invalid/payments-api:1.4.2
- Injected image: registry-01.example.invalid/paymnets-api:1.4.2
- Error: 

See result.json, decision.json when available, diagnostic.log, remediation.log,
Deployment snapshots, pods, events and registry-check.txt. Add the final screenshot in screenshots/.
Both api and metrics use the same missing typo image. The valid image exists.
A pass requires two simultaneous failures in the same trial Pod, scenario escalation,
action_executed=false, and unchanged post-injection Deployment spec and generation.
The diagnostic watcher is paused during injection, then resumed only once both failures
are observed. This prevents diagnosis racing the second pull; the decision deadline
includes diagnostic startup and is not a warmed latency measurement.
The script does not repair the workload after injection; faulted containers remain.
Save the evidence before resetting or deleting the lab.
Review all files for credentials and personal identifiers before publication.
