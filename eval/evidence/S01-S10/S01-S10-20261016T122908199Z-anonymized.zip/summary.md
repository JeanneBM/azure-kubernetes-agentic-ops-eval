# S01-S10 live functional batch

| Scenario | Verdict | Outcome | Mode | Duration (s) |
| --- | --- | --- | --- | ---: |
| S01 | pass | resolved | live agent workflow | 46.1 |
| S02 | pass | resolved | live agent workflow | 49.6 |
| S03 | pass | escalated | live agent workflow | 52.4 |
| S04 | pass | escalated | live agent workflow | 87.2 |
| S05 | inconclusive | escalated | live agent workflow | 80.1 |
| S06 | pass | escalated | scripted proposal / live remediation | 31.7 |
| S07 | pass | resolved | real model / controlled injection | 71.8 |
| S08 | pass | duplicate_delivery_checked | scripted proposal / live remediation | 74.4 |
| S09 | pass | escalated | scripted proposal / live remediation | 71.4 |
| S10 | pass | escalated | scripted proposal / live remediation | 64.1 |

Scenarios run sequentially against one isolated lab. Each prepares a healthy baseline.
S06, S08, S09 and S10 use scripted proposals; S07 uses the real model.
Failed/inconclusive results remain recorded. This is one functional repetition per scenario.
Archives are anonymized automatically before packaging.
The lab is retained after the batch. Remove it with the existing cleanup script after downloading evidence.
