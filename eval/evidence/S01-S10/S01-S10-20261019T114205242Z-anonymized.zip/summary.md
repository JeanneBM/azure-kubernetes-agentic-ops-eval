# S01-S10 live functional batch

| Scenario | Verdict | Outcome | Mode | Duration (s) |
| --- | --- | --- | --- | ---: |
| S01 | pass | resolved | live agent workflow | 54.2 |
| S02 | pass | resolved | live agent workflow | 53.8 |
| S03 | pass | escalated | live agent workflow | 52.8 |
| S04 | inconclusive | setup_fault_not_observed | live agent workflow | 356 |
| S05 | inconclusive | escalated | live agent workflow | 59.1 |
| S06 | pass | escalated | scripted proposal / live remediation | 39.2 |
| S07 | pass | resolved | real model / controlled injection | 66.8 |
| S08 | pass | duplicate_delivery_checked | scripted proposal / live remediation | 72 |
| S09 | pass | escalated | scripted proposal / live remediation | 70.5 |
| S10 | pass | escalated | scripted proposal / live remediation | 70.3 |

Scenarios run sequentially against one isolated lab. Each prepares a healthy baseline.
S06, S08, S09 and S10 use scripted proposals; S07 uses the real model.
Failed/inconclusive results remain recorded. This is one functional repetition per scenario.
Archives are anonymized automatically before packaging.
The lab is retained after the batch. Remove it with the existing cleanup script after downloading evidence.
