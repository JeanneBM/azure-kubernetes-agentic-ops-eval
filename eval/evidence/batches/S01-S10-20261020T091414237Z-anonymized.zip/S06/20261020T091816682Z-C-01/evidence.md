# S06 live trial
- Verdict: inconclusive
- Outcome: setup_error
- Error: Expected single diagnostic replica.

Proposal source: . Scripted mode uses a declared fixture, not LLM diagnosis.
A dedicated diagnostic Pod uses real Workload Identity, AKS evidence and the
authenticated remediation API. A test-only barrier holds the proposal until the
evaluator changes the Deployment image. The original watcher is paused.
Pass requires the explicit stale-image refusal, no executed action, and unchanged
Deployment spec/generation after the separately recorded external mutation.
This is a controlled functional integration trial, not an automatic watcher latency test.
Model abstention or a different refusal is inconclusive, never a stale-action pass.
The evaluator Pod is removed and the watcher resumed after evidence collection.
Review snapshots and logs before publication; use audit logs for exhaustive write history.
