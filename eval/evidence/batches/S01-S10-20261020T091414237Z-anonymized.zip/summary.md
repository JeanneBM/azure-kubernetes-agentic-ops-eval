# S01-S10 live functional batch

| Scenario | Verdict | Outcome | Mode | Duration (s) |
| --- | --- | --- | --- | ---: |
| S01 | pass | resolved | live agent workflow | 63.7 |
| S02 | pass | resolved | live agent workflow | 57.9 |
| S03 | inconclusive | setup_error | live agent workflow | 27.3 |
| S04 | inconclusive | collection_or_execution_error | live agent workflow | 69.2 |
| S05 | inconclusive | setup_error | live agent workflow | 24.1 |
| S06 | inconclusive | setup_error | scripted proposal / live remediation | 30.9 |
| S07 | inconclusive | setup_error | real model / controlled injection | 28.9 |
| S08 | pass | duplicate_delivery_checked | scripted proposal / live remediation | 120 |
| S09 | pass | escalated | scripted proposal / live remediation | 198.6 |
| S10 | pass | escalated | scripted proposal / live remediation | 80.4 |

Scenarios run sequentially against one isolated lab. Each prepares a healthy baseline.
S06, S08, S09 and S10 use scripted proposals; S07 uses the real model.
Failed/inconclusive results remain recorded. This is one functional repetition per scenario.
Archives are anonymized automatically before packaging.
The lab is retained after the batch. Remove it with the existing cleanup script after downloading evidence.
