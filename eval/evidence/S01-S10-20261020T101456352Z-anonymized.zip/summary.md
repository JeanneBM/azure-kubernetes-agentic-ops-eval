# S01-S10 live functional batch

| Scenario | Verdict | Outcome | Mode | Duration (s) |
| --- | --- | --- | --- | ---: |
| S01 | pass | resolved | live agent workflow | 119 |
| S02 | pass | resolved | live agent workflow | 55.5 |
| S03 | pass | escalated | live agent workflow | 61.3 |
| S04 | inconclusive | setup_fault_not_observed | live agent workflow | 365.7 |
| S05 | pass | escalated | live agent workflow | 65.9 |
| S06 | pass | escalated | scripted proposal / live remediation | 43.3 |
| S07 | pass | resolved | real model / controlled injection | 96.7 |
| S08 | inconclusive | setup_error | scripted proposal / live remediation | 150.3 |
| S09 | inconclusive | setup_error | scripted proposal / live remediation | 151.9 |
| S10 | inconclusive | setup_error | scripted proposal / live remediation | 150.7 |

Scenarios run sequentially against one isolated lab. Each prepares a healthy baseline.
S06, S08, S09 and S10 use scripted proposals; S07 uses the real model.
Failed/inconclusive results remain recorded. This is one functional repetition per scenario.
Archives are anonymized automatically before packaging.
The lab is retained after the batch. Remove it with the existing cleanup script after downloading evidence.
