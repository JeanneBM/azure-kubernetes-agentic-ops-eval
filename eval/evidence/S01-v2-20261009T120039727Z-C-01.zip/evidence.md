# S01 live trial

- Variant: C (LLM-assisted diagnostic and deterministic remediation)
- Observed outcome: resolved
- Scenario verdict: pass
- Fault start UTC: 2026-10-09T12:00:44Z
- Intended image: acragentevalf9b4c0b810.azurecr.io/payments-api:1.4.2
- Injected image: acragentevalf9b4c0b810.azurecr.io/paymnets-api:1.4.2
- Error: 

See result.json, decision.json when available, diagnostic.log, remediation.log,
Deployment snapshots, pods and events. Add the final screenshot in screenshots/.
No manual repair was performed after injection. A pass requires the agent audit,
healthy rollout and restoration of the original Deployment spec. This is one
live trial, not a five-run batch or a comparison with a baseline. Failure Pod
capture is best effort; missing files are evidence gaps. If agents restarted,
Deployment logs may omit earlier containers; consult agents-before/after.json.
Review all files for credentials and personal identifiers before publication.
