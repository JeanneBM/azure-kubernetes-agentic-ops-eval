# S02 live trial

- Variant: C (LLM-assisted diagnostic and deterministic remediation)
- Observed outcome: resolved
- Scenario verdict: pass
- Fault start UTC: 2026-10-09T10:56:48Z
- Intended image: registry-02.example.invalid/payments-api:1.4.2
- Injected image: registry-02.example.invalid/paymnets-api:1.4.2
- Error: 

See result.json, decision.json when available, diagnostic.log, remediation.log,
Deployment snapshots, pods and events. deployment-before.json includes the healthy metrics sidecar; deployment-before-preparation.json records the original workload. Add the final screenshot in screenshots/.
No manual repair was performed after injection. A pass requires the agent audit,
healthy rollout and restoration of the pre-injection Deployment spec, including the unchanged sidecar. Sidecar preparation occurs before injection and is retained after the trial. This is one
live trial, not a five-run batch or a comparison with a baseline. Failure Pod
capture is best effort; missing files are evidence gaps. If agents restarted,
Deployment logs may omit earlier containers; consult agents-before/after.json.
Review all files for credentials and personal identifiers before publication.
